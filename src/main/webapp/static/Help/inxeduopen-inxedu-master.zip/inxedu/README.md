**免费开源网校系统源代码轻松搭建在线教育平台**

因酷交流群①：468278040 (满)</br>

<p>因酷交流群②：164295773</p></br>
<p>因酷交流群③：456673541</p></br>

官网:[http://www.inxedu.com](http://www.inxedu.com)</br>

演示站:[http://wx.inxedu.com](http://http://wx.inxedu.com)</br>

账号:demo@inxedu.com</br>

密码:111111</br>
</br>
网站功能模块:</br>

课程功能</br>

咨询功能</br>

问答功能</br>

首页banner推荐</br>

播放模块</br>

个人中心模块</br>

个人资料模块</br>

修改头像模块</br>

收藏课程模块</br>

问题总结:
项目导入如果get set报错请添加lombok插件就可以正常使用了</br>

**技术框架**  </br>

核心框架：Spring Framework</br>

视图框架：Spring MVC </br>

持久层框架：MyBatis 3</br>

JS框架：jQuery</br>

富文本：kindeditor</br>

**开发环境**</br>

建议开发者使用以下环境，这样避免版本带来的问题</br>

IDE:eclipse，idea</br>

DB:Mysql5.5</br>

JDK:JAVA 7</br>

tomcat:tomcat 7.0.68以上</br>

项目文档：
http://note.youdao.com/groupshare/?token=673A1F2BB3B64A81A72CBD0AFE2D1F86&gid=9574975

**系统美图**

![输入图片说明](http://git.oschina.net/uploads/images/2016/0323/163323_c22814d9_133935.png "首页")

【使用声明】
尊敬的用户您好，欢迎使用因酷教育软件开源网校程序。
1、用户可直接用于研究或非盈利公益使用，但禁止用于商业用途，不允许去除因酷（inxedu）尾部版权标识，请尊重开源工作者的奉献，如有违反，本公司将依法追究法律责任。
2、本公司自成立以来，得到了广大教育从业者的热情支持和参与，在授权会员人力、资源、经费的保证下，本平台方得以生存、发展和壮大，目前已成为国内最大的互联网教育开源平台，在此对积极参与本站建设的朋友表示感谢。